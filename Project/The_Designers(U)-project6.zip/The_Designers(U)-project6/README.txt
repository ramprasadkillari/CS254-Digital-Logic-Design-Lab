
------------------------------
				PROJECT 6 :  WRITE CONFIGURATION LOGIC    THE DESIGNERS - GROUP (U)

170050068
170050074     
170050083  
170050093  
170050102

-------------------------------

On Reset input high, we move to IDLE state. This is not shown in FSM.
Wr_complete is checked for logic high only in the very first clock cycle. This is not shown in FSM.
iRd_Data is de-asserted at the end of packet. This is not shown in FSM.
 
-------------------------------

6_TheDesigners(U).vhd file contains generic variable N.
 
There are 4 test cases written in 6_The_Designers(U)_testbench.vhd. 
At a time one test case should be uncommented and the other three should be commented.
The corresponding value of N for a testcase should be changed at the topmost line of the file 6_TheDesigners(U).vhd inside entity write_config.

The value of N for testcase1 and testcase2 are 30.
The value of N for testcase3 is 6.
The value of N for testcase4 is 2.

-------------------------------

The Zip folder contains 6_TheDesigners(U).pdf which is a 1pg report and 6_TheDesigners(U)_2pg.pdf which is a 2pg report.
